<?php


class Glist extends Eloquent{
	protected $table = "laundrylist";

	protected $guarded = array();
}