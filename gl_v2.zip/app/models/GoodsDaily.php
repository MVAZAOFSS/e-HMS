<?php


class GoodsDaily extends Eloquent{
	protected $table = "storegoodsdaily";

	protected $guarded = array();
}