<?php


class GoodsInfo extends Eloquent{
	protected $table = "storegoodsinfo";

	protected $guarded = array();
}