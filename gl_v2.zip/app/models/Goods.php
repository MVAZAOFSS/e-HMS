<?php


class Goods extends Eloquent{
	protected $table = "storegoodstotal";

	protected $guarded = array();
}