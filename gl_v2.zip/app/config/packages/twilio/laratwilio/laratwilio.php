<?php

return array(

	"accountSid" => "AC065c9939b6692b7a58d5f158ab49d709", // Your Twilio account sid
	"authToken" => "e75686c5e77f807c866c2a31c86f0634", // Your Twilio auth token
	"fromNumber" => "+13212749760" //Your Default from number - for sending SMS messages out - must be a registered and sms-capable Twilio number
);