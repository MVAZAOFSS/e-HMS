<?php

class GuestsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('guests')->truncate();

		$guests = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('guests')->insert($guests);
	}

}
