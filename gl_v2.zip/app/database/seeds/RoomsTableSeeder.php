<?php

class RoomsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('rooms')->truncate();

		$rooms = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('rooms')->insert($rooms);
	}

}
