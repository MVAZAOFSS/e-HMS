<?php

class BillsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('bills')->truncate();

		$bills = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('bills')->insert($bills);
	}

}
