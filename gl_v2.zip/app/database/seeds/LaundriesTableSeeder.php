<?php

class LaundriesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('laundries')->truncate();

		$laundries = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('laundries')->insert($laundries);
	}

}
