<?php

/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register all of the routes for an application.
  | It's a breeze. Simply tell Laravel the URIs it should respond to
  | and give it the Closure to execute when that URI is requested.
  |
 */

//System Setup
Route::get('setup', 'SystemController@login');
Route::post('system/setup', 'SystemController@validate');
Route::get('system', 'SystemController@systemApp');
Route::get('system/config', 'SystemController@conf');



Route::get('password', function(){
  return View::make('pass.index');
});
Route::post('password/pax', 'PasswordController@pax');
Route::post('password/change', 'PasswordController@change');
Route::get('password/users', 'PasswordController@show');
Route::post('password/users', 'PasswordController@update');


Route::get('/', function()
{
  
	return View::make('login');
});

Route::get('home', array('before'=>'auth', function()
{
  return View::make('dashboard');
}));


//validating user during login
Route::post('login',array('as'=>'login', 'uses'=>'UsersController@validate'));

//check default pass
Route::get('passchange',array('as'=>'passchange', 'uses'=>'UsersController@passchange'));
Route::post('passchange',array('as'=>'passchange1', 'uses'=>'UsersController@paxchn'));

//loging a user out
Route::get('logout',array('as'=>'logout', 'uses'=>'UsersController@logout'));

//user codes
Route::get('users/add', array('as'=>'adduser', 'uses'=>'UsersController@create'));
Route::post('users/add', array('as'=>'adduser1', 'uses'=>'UsersController@store'));
Route::get('users', array('as'=>'listusers', 'uses'=>'UsersController@index'));
Route::post('users/delete/{id}', array('as'=>'listusers', 'uses'=>'UsersController@destroy'));
Route::get('user/edit/{id}', array('as'=>'edituser', 'uses'=>'UsersController@edit'));
Route::post('user/edit/{id}', array('as'=>'edituser1', 'uses'=>'UsersController@update'));
//room codes
Route::get('rooms/repair', array('as'=>'addroom', 'uses'=>'RoomsController@repair'));
Route::post('rooms/repair', array('as'=>'addroom', 'uses'=>'RoomsController@postrepair'));
Route::get('rooms/repairs', array('as'=>'addroom', 'uses'=>'RoomsController@repairs'));
Route::get('rooms/add', array('as'=>'addroom', 'uses'=>'RoomsController@create'));
Route::get('rooms/release', array('as'=>'showrelease', 'uses'=>'RoomsController@showrelease'));
Route::get('rooms/requests', array('as'=>'showrequests', 'uses'=>'RoomsController@showrequests'));
Route::post('rooms/requests/{id}', array('as'=>'postrequests', 'uses'=>'RoomsController@postrequests'));
Route::post('rooms/add', array('as'=>'addroom1', 'uses'=>'RoomsController@store'));
Route::post('rooms/addday', array('as'=>'addday', 'uses'=>'RoomsController@addday'));
Route::get('rooms', array('as'=>'listrooms', 'uses'=>'RoomsController@index'));
Route::post('rooms/delete/{id}', array('as'=>'listrooms', 'uses'=>'RoomsController@destroy'));
Route::get('rooms/edit/{id}', array('as'=>'editroom', 'uses'=>'RoomsController@edit'));
Route::post('rooms/edit/{id}', array('as'=>'editroom1', 'uses'=>'RoomsController@update'));
Route::post('guest/roomcheck', 'RoomsController@roomcheck');
Route::post('rooms/release/{id}', array('as'=>'release', 'uses'=>'RoomsController@release'));
//bar codes
Route::get('bar/add', array('as'=>'addroom', 'uses'=>'BarsController@create'));
Route::post('bar/add', array('as'=>'addroom1', 'uses'=>'BarsController@store'));
Route::get('bar', array('as'=>'listrooms', 'uses'=>'BarsController@index'));
Route::post('bar/delete/{id}', array('as'=>'listrooms', 'uses'=>'BarsController@destroy'));
Route::get('bar/edit/{id}', array('as'=>'editroom', 'uses'=>'BarsController@edit'));
Route::post('bar/edit/{id}', array('as'=>'editroom1', 'uses'=>'BarsController@update'));
//restaurant codes
Route::get('restaurant/add', array('as'=>'addrestaurant', 'uses'=>'RestaurantsController@create'));
Route::post('restaurant/add', array('as'=>'addrestaurant1', 'uses'=>'RestaurantsController@store'));
Route::get('restaurant', array('as'=>'listrestaurants', 'uses'=>'RestaurantsController@index'));
Route::post('restaurant/delete/{id}', array('as'=>'listrestaurants', 'uses'=>'RestaurantsController@destroy'));
Route::get('restaurant/edit/{id}', array('as'=>'editrestaurant', 'uses'=>'RestaurantsController@edit'));
Route::post('restaurant/edit/{id}', array('as'=>'editrestaurant1', 'uses'=>'RestaurantsController@update'));
//laundry codes
Route::get('laundry/add', array('as'=>'addlaundry', 'uses'=>'LaundriesController@create'));
Route::post('laundry/add', array('as'=>'addlaundry1', 'uses'=>'LaundriesController@store'));
Route::get('laundry/list', array('as'=>'laundrylist', 'uses'=>'LaundriesController@listgl'));
Route::post('laundry/glist', array('as'=>'laundrylistg', 'uses'=>'LaundriesController@glist'));
Route::post('laundry/llist', array('as'=>'laundrylist', 'uses'=>'LaundriesController@llist'));
Route::post('laundry/viewlist', array('as'=>'viewlist', 'uses'=>'LaundriesController@viewlist'));
Route::post('laundry/viewlist1', array('as'=>'viewlist1', 'uses'=>'LaundriesController@viewlist1'));
Route::post('laundry/list', array('as'=>'plaundrylist', 'uses'=>'LaundriesController@plistgl'));
Route::get('laundry', array('as'=>'listlaundry', 'uses'=>'LaundriesController@index'));
Route::post('laundry/delete/{id}', array('as'=>'listlaundry', 'uses'=>'LaundriesController@destroy'));
Route::get('laundry/edit/{id}', array('as'=>'editlaundry', 'uses'=>'LaundriesController@edit'));
Route::post('laundry/edit/{id}', array('as'=>'editlaundry1', 'uses'=>'LaundriesController@update'));
Route::get('laundry/gllists', array('as'=>'gllists', 'uses'=>'LaundriesController@gllists'));
//guest codes
Route::get('guest/add', array('as'=>'addguest', 'uses'=>'GuestsController@create'));
Route::get('guest/list', array('as'=>'listguest', 'uses'=>'GuestsController@index'));
Route::post('guest/add', array('as'=>'addguest1', 'uses'=>'GuestsController@store'));
Route::post('guest/rno', array('as'=>'addguest1', 'uses'=>'GuestsController@rno'));
Route::get('guest', array('as'=>'listguest', 'uses'=>'GuestsController@index'));
Route::post('guest/delete/{id}', array('as'=>'listguest', 'uses'=>'GuestsController@destroy'));
Route::get('guest/edit/{id}', array('as'=>'editguest', 'uses'=>'GuestsController@edit'));
Route::post('guest/edit/{id}', array('as'=>'editguest1', 'uses'=>'GuestsController@update'));
Route::get('guest/edit/{id}', array('as'=>'editguest', 'uses'=>'GuestsController@edit'));
Route::post('guest/edit/{id}/moredays', array('as'=>'editguest1', 'uses'=>'GuestsController@moredays'));
Route::get('guest/messages', array('as'=>'messages', 'uses'=>'GuestsController@messages'));
Route::post('guest/messages/{id}', array('as'=>'messages1', 'uses'=>'GuestsController@confirm'));
Route::get('guest/checkouts', array('as'=>'checkouts', 'uses'=>'GuestsController@checkouts'));
//notification 
Route::get('notifications', array('as'=>'notifications', 'uses'=>'NotificationsController@index'));
Route::post('notifications/solved/{id}', array('as'=>'notificationssolved', 'uses'=>'NotificationsController@solving'));
Route::get('notify', array('as'=>'notify', 'uses'=>'NotificationsController@notify'));
//bill codes
Route::get('bill/add', array('as'=>'bill', 'uses'=>'BillsController@index'));
Route::post('bill/submit', array('as'=>'billsubmit', 'uses'=>'BillsController@submit'));
Route::post('bill/add', array('as'=>'billstore', 'uses'=>'BillsController@store'));
Route::get('bill', array('as'=>'allbill', 'uses'=>'BillsController@all'));
Route::get('bill/all',  array('as'=>'allbill', 'uses'=>'BillsController@all'));
Route::post('loadbill', 'BillsController@loadbill');
Route::post('bill/loadbill', 'BillsController@loadbill');
Route::post('bill/updatebill', 'BillsController@updatebill');
Route::post('bill/servicetime', 'BillsController@servicetime');
Route::get('bill/sales/add', 'BillsController@sales');
Route::post('bill/sales/submitsale', 'BillsController@submitsale');
Route::get('bill/sales/all','BillsController@allsale');
// Storekeeper codes
Route::get('good/set', 'StoresController@create');
Route::post('good/set', 'StoresController@store');
Route::get('goods/manage', 'StoresController@manage');
Route::get('goods/report', 'StoresController@report');
Route::post('goods/process_add', 'StoresController@process_add');
Route::post('goods/process_reduce', 'StoresController@process_reduce');
//Reports
Route::get('reports/rooms', 'ReportsController@rooms');
Route::post('reports/laundry', 'ReportsController@postlaundry');
Route::post('reports/rooms', 'ReportsController@postrooms');
Route::get('reports/restaurant', 'ReportsController@restaurant');
Route::post('reports/restaurant', 'ReportsController@postrestaurant');
Route::get('reports/bar', 'ReportsController@bar');
Route::post('reports/bar', 'ReportsController@postbar');
Route::get('reports/laundry', 'ReportsController@laundry');
Route::get('reports/notify', array('as'=>'notify', 'uses'=>'NotificationsController@notify'));
//Accountant
Route::get('accountant/income', 'AccountantController@income');
Route::get('accountant/expenditure', 'AccountantController@expenditure');
Route::get('accountant/report', 'AccountantController@report');
