@extends('layout.master')

@section('content')
<div id="wrapper">
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
<div class="navbar-header">
<a class="navbar-brand visible-lg" href="{{url("/home")}}">
	<p style="color: #000">Bar manager </p>
</a>
<a class="navbar-brand hidden-lg" href='#'>
	 <p>EMIS</p>
</a>
</div>

@include('sidebar')
</nav>

<div id="page-wrapper">
  <div class="well well-sm"> <i class="glyphicon glyphicon-export"></i> Expenses of  {{date('d/m/Y')}} </div>

  <div class="well well-sm"> 
  		Expenditure on: <br/><br/>
  		<select>
  			<option></option>
  			<option>ROOMS</option>
  			<option>BAR/DRINKS/BEVERAGES</option>
  			<option>RESTAURANT FOODS</option>
  			<option>OTHERS</option>
  		</select>
  		<br/><br/>
  		Amount<br/>
  		<input type="text" />
  		<br/><br/>
  		<button class="btn btn-success">Add Expenditure </button>
  </div>


  <div class="well well-sm"> 
    <p><b>TOTAL INCOME </b></p>
  </div>

</div>   
</div>  
@stop