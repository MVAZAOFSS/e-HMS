@extends('layout.master')

@section('content')
<div id="wrapper">
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
<div class="navbar-header">
<a class="navbar-brand visible-lg" href="{{url("/home")}}">
	<p style="color: #000">Hotel administration</p>
</a>
<a class="navbar-brand hidden-lg" href='#'>
	 <p>EMIS</p>
</a>
</div>
@include('layout-setup')
@include('sidebar')
</nav>

<div id="page-wrapper" style="background-color:#fff">
<ol class="breadcrumb">
            <li><a href="{{ url('home') }}">Home</a></li>
            <li class="active">Rooms reports </li>
                           
</ol>
<hr/>
<p id="loader" style="display:none; z-index: 3000; position: absolute; top: 92px; left: 480px"><span style="background-color: #f5f5f5; padding:8px; border:1px solid #dd6 ; border-radius:4px"><img src="{{url("img/load.gif")}}"> <b>fetching report ...</b></span></p>
<p id="ir" style="border: 1px solid #dd6; padding: 3px; border-left:4px solid #dd7;background-color:#f5f5f5">
    Report of: 
    <select id="reportof" style="border: 1px solid #002;padding:2px">
        <option></option>
        <option value="Guest">Guest</option>
        <option value="income">income</option>
    </select>
    Rooms:     
    <select id="rooms" style="border: 1px solid #002;padding:2px">
        <option></option>
        <option value="all">all</option>
        <option value="reserved">reserved</option>
        <option value="paid">paid</option>
    </select>
    Report for: 
    <select id="reportfor" style="border: 1px solid #002;padding:2px">
        <option></option>
        <option value="daily">daily</option>
        <option value="weekly">weekly</option>
        <option value="monthly">monthly</option>
        <option value="yearly">yearly</option>
    </select>   
    <span id="daily" style="display:none">
     Date:   
    <input id="date" style="width: 90px;border: 1px solid #002;padding:2px" type="text" />  
    </span>
    <span id="weekly" style="display:none">
     start   
    <input id="start" style="width: 90px;border: 1px solid #002;padding:2px" type="text" /> 
     end   
    <input id="end" style="width: 90px;border: 1px solid #002;padding:2px" type="text" />  
    </span>
    <span id="monthly" style="display:none">
    <select id="month" style="border: 1px solid #002;padding:2px">
        <option></option>
        <option value="january">january</option>
        <option value="february">february</option>
        <option value="march">march</option>
        <option value="april">april</option>
        <option value="may">may</option>
        <option value="june">june</option>
        <option value="july">july</option>
        <option value="august">august</option>
        <option value="september">september</option>
        <option value="october">october</option>
        <option value="november">november</option>
        <option value="december">december</option>
    </select>
    <input type="text" placeholder="Year" value="{{date('Y')}}" id="mYear" style="width: 90px;border: 1px solid #002;padding:2px" />  
    </span>
    <span id="yearly" style="display:none">
     <input id="year" style="width: 90px;border: 1px solid #002;padding:2px" value="{{date('Y')}}"  type="text" />  
    </span>
    Report in: 
    <select id="reportin" style="border: 1px solid #002;padding:2px">
        <option></option>
        <option value="Table">Table</option>
        <option class="chart" style="display:none" value="Line">Line</option>
        <option class="chart" style="display:none" value="Pie">Pie</option>
        <option class="chart" style="display:none" value="Column">Column</option>            
    </select>
    <button id="go">Go</button>
</p>
<hr />

<div id="ireport"></div>
<div id="container" style="border-radius: 8px"></div>

</div>   


<script type="text/javascript">


$(document).ready(function(){

    $('#date, #start, #end').datepicker({
        dateFormat:"yy-mm-dd",
        changeMonth: true,
        changeYear:true,
        maxDate: 0
    });


    $('#reportfor').on('change', function(){
        var rf = $(this).val();
        if(rf == "daily"){
            $(".chart").hide();
            $('#reportin').val('');
            $('#weekly').hide();
            $('#monthly').hide();
            $('#yearly').hide();
            $('#daily').fadeIn(1000);
        }else if(rf == "weekly"){
            $(".chart").show();
            $('#daily').hide();
            $('#monthly').hide();
            $('#yearly').hide();
            $('#weekly').fadeIn(1000);
        }else if(rf == "yearly"){
            $(".chart").show();
            $('#reportin').val('');
            $('#daily').hide();
            $('#weekly').hide();
            $('#monthly').hide();
            $('#yearly').fadeIn(1000);
        }else if(rf == "monthly"){
            $(".chart").show();
            $('#reportin').val('');
            $('#daily').hide();
            $('#weekly').hide();
            $('#yearly').hide();
            $('#monthly').fadeIn(1000);
        }
    });
    /////////////////////////////////////////////////////
    $('#go').on('click', function(){

        

        $('#ir').css('opacity', '0.1');

        var reportof   = $('#reportof').val();
        var rooms      = $('#rooms').val();
        var reportin   = $('#reportin').val();

        var reportfor  = $('#reportfor').val();
        if(reportfor==""||rooms==""||reportin==""||reportof==""){
            alert("Please fill the fields first!");
            $('#ir').css('opacity', '1');
        }else{
            if(reportfor == "daily"){
                var date = $('#date').val();
                if(date == ""){
                    alert("Please enter date first");
                    $('#ir').css('opacity', '1');
                }else{
                    $('#ireport').html("");
                    $('#loader').show();
                    //code for daily goes down
                    $.post('rooms', {rf:reportfor, ro:reportof, rms:rooms, ri:reportin, date:date}, function(data){
                        if(reportin == "Table"){
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            $('#ireport').hide().html(data).fadeIn(100); 
                        }else{
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            var obj = JSON.parse(data);
                                
                                var chart = new Highcharts.Chart({
                                    chart: {
                                        renderTo: 'ireport',
                                        height: 400,
                                        type: obj.chartType
                                    },
                                    title: {
                                        text: obj.gtitle,
                                        x: -20 //center
                                    },
                                    subtitle: {
                                        text: obj.gsubtitle,
                                        x: -20
                                    },
                                    xAxis: {
                                        categories: obj.xAxisData
                                    },
                                     yAxis: {
                                        title: {
                                            text: obj.yAxisTitle
                                        },
                                        plotLines: [{
                                            value: 0,
                                            width: 1,
                                            color: '#808080'
                                        }]
                                    },
                                    
                                    series: [{
                                        name: obj.gname,
                                        data: obj.yAxisData        
                                    }]
                                });
                        }
                                               
                    });
                }
            }else if(reportfor == "weekly"){
                var start = $('#start').val();
                var end = $('#end').val();
                if(start == "" || end == ""){
                    alert("Please fill the fields first");
                    $('#ir').css('opacity', '1');
                }else{
                    $('#ireport').html("");
                    $('#loader').show();
                    //code for weekly goes down
                    $.post('rooms', {rf:reportfor, ro:reportof, rms:rooms, ri:reportin, start:start, end:end}, function(data){
                if(reportin == "Table"){
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            $('#ireport').hide().html(data).fadeIn(100); 
                        }else{
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            var obj = JSON.parse(data);
                                
                                var chart = new Highcharts.Chart({
                                    chart: {
                                        renderTo: 'ireport',
                                        height: 400,
                                        type: obj.chartType
                                    },
                                    title: {
                                        text: obj.gtitle,
                                        x: -20 //center
                                    },
                                    subtitle: {
                                        text: obj.gsubtitle,
                                        x: -20
                                    },
                                    xAxis: {
                                        categories: obj.xAxisData
                                    },
                                     yAxis: {
                                        title: {
                                            text: obj.yAxisTitle
                                        },
                                        plotLines: [{
                                            value: 0,
                                            width: 1,
                                            color: '#808080'
                                        }]
                                    },
                                    
                                    series: [{
                                        name: obj.gname,
                                        data: obj.yAxisData        
                                    }]
                                });
                        }                      
                    });
                }
            }else if(reportfor == "monthly"){
                var month = $('#month').val();
                var mYear = $('#mYear').val();
                if(month == "" || mYear == ""){
                    alert("Please choose month first");
                    $('#ir').css('opacity', '1');
                }else{
                    $('#ireport').html("");
                    $('#loader').show();
                    //code for monthly goes here
                    $.post('rooms', {rf:reportfor, ro:reportof, rms:rooms, ri:reportin, month:month, mYear:mYear}, function(data){
                    if(reportin == "Table"){
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            $('#ireport').hide().html(data).fadeIn(100); 
                        }else{
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            var obj = JSON.parse(data);
                                
                                var chart = new Highcharts.Chart({
                                    chart: {
                                        renderTo: 'ireport',
                                        height: 400,
                                        type: obj.chartType
                                    },
                                    title: {
                                        text: obj.gtitle,
                                        x: -20 //center
                                    },
                                    subtitle: {
                                        text: obj.gsubtitle,
                                        x: -20
                                    },
                                    xAxis: {
                                        categories: obj.xAxisData
                                    },
                                     yAxis: {
                                        title: {
                                            text: obj.yAxisTitle
                                        },
                                        plotLines: [{
                                            value: 0,
                                            width: 1,
                                            color: '#808080'
                                        }]
                                    },
                                    
                                    series: [{
                                        name: obj.gname,
                                        data: obj.yAxisData        
                                    }]
                                });
                        }                       
                    });
                }
            }else if(reportfor == "yearly"){
                var year = $('#year').val();
                if(year == ""){
                    alert("Please enter year first");
                    $('#ir').css('opacity', '1');
                }else{
                    $('#ireport').html("");
                    $('#loader').show();
                    //code for yearly goes here
                    $.post('rooms', {rf:reportfor, ro:reportof, rms:rooms, ri:reportin, yr:year}, function(data){
                        if(reportin == "Table"){
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            $('#ireport').hide().html(data).fadeIn(100); 
                        }else{
                            $('#loader').hide();
                            $('#ir').css('opacity', '1');
                            var obj = JSON.parse(data);
                                
                                var chart = new Highcharts.Chart({
                                    chart: {
                                        renderTo: 'ireport',
                                        height: 400,
                                        type: obj.chartType
                                    },
                                    title: {
                                        text: obj.gtitle,
                                        x: -20 //center
                                    },
                                    subtitle: {
                                        text: obj.gsubtitle,
                                        x: -20
                                    },
                                    xAxis: {
                                        categories: obj.xAxisData
                                    },
                                     yAxis: {
                                        title: {
                                            text: obj.yAxisTitle
                                        },
                                        plotLines: [{
                                            value: 0,
                                            width: 1,
                                            color: '#808080'
                                        }]
                                    },
                                    
                                    series: [{
                                        name: obj.gname,
                                        data: obj.yAxisData        
                                    }]
                                });
                        }                       
                                         
                    });
                }
            }
        }
    });
});
</script>  
@stop