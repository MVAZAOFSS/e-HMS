<div style="margin-right: 85px;">
<ul class="nav navbar-nav navbar-right">

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
            <span class="label label-primary">
                <span class="glyphicon glyphicon-cog"></span> Layout     
            </span>    
           </a>
          <ul class="dropdown-menu">
            <li id="min"><a href="#" onclick="javascript:minSide()"><span class="glyphicon glyphicon-circle-arrow-left"></span> <label class="label label-success">Hide Sidebar</label></a></li>
            <li id="max" style="display:none"><a href="#" onclick="javascript:maxSide()"><span class="glyphicon glyphicon-circle-arrow-right"></span> <label class="label label-success">Show Sidebar</label></a></li>
            <li class="divider"></li>
            
          </ul>
        </li>
      </ul>
</div>