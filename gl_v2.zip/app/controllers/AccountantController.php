<?php

class AccountantController extends BaseController{
	public function income(){
		return View::make('accountant.income');
	}
	public function expenditure(){
		return View::make('accountant.expenditure');
	}
	public function report(){
		return View::make('accountant.report');
	}
}